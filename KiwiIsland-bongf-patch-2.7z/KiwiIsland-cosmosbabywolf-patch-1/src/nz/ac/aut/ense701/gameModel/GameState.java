
package nz.ac.aut.ense701.gameModel;

/**
 * Enumeration for the current state of the game.
 * 
 * @author AS
 */
public enum GameState
{
    PLAYING, WON, LOST,MENU, OPTIONS;

}
